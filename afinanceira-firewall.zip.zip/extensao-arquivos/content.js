let historicoCliques = [];
let limiteAlertas = 10; // Cliques por minuto máximo tolerado

// Escuta todos os cliques na página de forma genérica
document.addEventListener('click', function(evento) {
    const agora = Date.now();
    historicoCliques.push(agora);

    // Filtra apenas os cliques feitos no último minuto (60000ms)
    historicoCliques = historicoCliques.filter(tempo => agora - tempo < 60000);

    console.log(`Frequência Atual: ${historicoCliques.length} ações/min`);

    // Se estourar a métrica de segurança, dispara a interface protetiva
    if (historicoCliques.length > limiteAlertas) {
        dispararBloqueioPreventivo();
    }
});

function dispararBloqueioPreventivo() {
    // Cria o pop-up de alerta direto na tela do usuário
    if (document.getElementById('alerta-afinarceira')) return;

    let alerta = document.createElement('div');
    alerta.id = 'alerta-afinarceira';
    alerta.innerHTML = `
        <div style="background:#0d0d0d; border:2px solid #D4AF37; color:white; padding:20px; position:fixed; top:20%; left:35%; z-index:999999; border-radius:10px; text-align:center; box-shadow: 0 0 20px rgba(0,0,0,0.8);">
            <h3 style="color:#FF0000; margin-top:0;">⚠️ Alerta de Overtrading Detectado</h3>
            <p>Sua atividade está acima do limite de segurança matemática para este ciclo.</p>
            <button onclick="document.getElementById('alerta-afinarceira').remove()" style="background:#D4AF37; color:black; border:none; padding:10px 20px; cursor:pointer; font-weight:bold; border-radius:4px;">Estabilizar Conta</button>
        </div>
    `;
    document.body.appendChild(alerta);
}